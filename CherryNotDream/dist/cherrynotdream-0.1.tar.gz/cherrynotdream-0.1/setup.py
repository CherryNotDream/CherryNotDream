from setuptools import setup, find_packages

setup(
    name='cherrynotdream',
    version='0.1',
    packages=find_packages(),
    description='Library to add text documents to Visual Studio Code projects',
    author='Maksim Zhbanov',
    author_email='your@email.com',
)